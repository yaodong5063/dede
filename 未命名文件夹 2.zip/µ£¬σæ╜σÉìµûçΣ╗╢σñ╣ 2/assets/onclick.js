$(function(){
 	$(".pp > ul > li > a").click(function(){
        $(".pp > ul > li > a").alert("style","background:url(/App/Home/View/default/Public/js/sp14.jpg)"); 
        $(this).css("background","#009044"); 
    });

    
	
});