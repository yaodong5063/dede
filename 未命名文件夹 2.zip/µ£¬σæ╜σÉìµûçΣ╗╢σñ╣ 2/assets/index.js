$(function(){
 	$(".in3n > ul > li > a").mouseover(function(){
        $(".in3n > ul > li > a").css("background",""); 
        $(this).css("background","#009044"); 
    });

    $(".in61_1y > ul > li > a").mouseover(function(){

        $(".in61_1y > ul > li > a ").css({"border":"1px solid #fff","color":"#646464","border-radius":"0px"}); 
        $(this).css({"border":"1px solid #67c12f","color":"#67c12f","border-radius":"3px"});
    });
    $('.fc_z,.fc_y').hide();
    
	
});





$(function(){
	// $(".project").mouseover(function(){
	// 	if($(this).children(".in2n_con").show()){
	// 		$('#ceng').show();
	// 	}
	// 	//
	// }).mouseout(function(){
	// 	$(this).children(".in2n_con").hide();
	// 	$('#ceng').hide();
	// })
	

	// $(".project").mouseover(function(){
	// 	if($(this).children(".in2n_con").show()){
	// 		$('#ceng').show();
	// 	}
	// }).mouseout(function(){
	// 	$(this).children(".in2n_con").hide();
	// 	$('#ceng').hide();
	// })

	$('.header_big').on('mouseover' , '.project' , function(){

		if($(this).children(".in2n_con").show()){
			$('#ceng').show();
		}

	})
	$('.header_big').on('mouseout' , '.project' , function(){

		if($(this).children(".in2n_con").hide()){
			$('#ceng').hide();
		}

	})
	

	 $(".in6xx1").mouseover(function(){
        $(".in6xx1").css("box-shadow","0 0 0px #ccc"); 
        $(this).css("box-shadow","0 0 4px #ccc");
    });


	$(".in6xx1s").mouseover(function(){
        $(".in6xx1s").children("h2").css("text-decoration","none");
        $(this).children("h2").css({"text-decoration":"underline","color":"#7e7e7e"});
    });

    var in2 = $('.header').width();
    var in2s = 0;
    $('.in2n_con').css({'width':in2+'px','left':'0px'});
    //$('.in2n_con').css('width',in2+'px');
     //alert(in2s);

    // var bheight = $(window).height();
    // $(".banner").css("height",bheight);
    if(location.pathname.indexOf('Home/News/news') >= 0 || location.pathname.indexOf('Home/News/index') >= 0){
		$(".header").css({
			position: 'static',
		}).next('div').hide();
		$("header").hide();
    	$(".header").show();
	}
    $(window).scroll(function(){
    	// location.pathname.indexOf('Home/Info/info') >= 0  ||
    	if( location.pathname.indexOf('Home/News/index') >= 0 || location.pathname.indexOf('Home/News/news') >= 0){
    		$(".header").css({
    			position: 'static',
    		}).next('div').hide();
    		$("header").hide();
	    	$(".header").show();

    		return false;
    	}
    	var iheight = $("#banner").height();
	    var gheight = $(document).scrollTop();
	    if((gheight+100)>iheight){
	    	$("header").hide();
	    	$(".header").show();
	    }else {
	    	$("header").show();
	    	$(".header").hide();
	    }

    })
	$("#ceng").css("height",bheight+"px");

	// if(location.pathname.indexOf('Home/Info/info') >= 0){
	// 	$("#content").find('tr').eq(0).css({
	// 		'background' : '#ba1718','color' : '#ffffff', 'height' : 50 , 
	// 	});
	// 	return false;
	// }
    
});